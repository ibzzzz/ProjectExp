﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RestSharp;
using System.Xml;
using System.Text;
using System.Security.Cryptography;

namespace ProjectExp
{
    public partial class _Default : Page
    {
        RestClient client = new RestClient("http://api.ean.com");
        RestRequest searchRequest = new RestRequest("/ean-services/rs/hotel/v3/list", Method.GET);
        public string _hotelId = "";

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public class CachedSupplierResponse
        {
            public string supplierCacheTolerance
            {
                get;
                set;
            }
            public string cachedTime
            {
                get;
                set;
            }
            public string candidatePreptime
            {
                get;
                set;
            }
            public string otherOverheadTime
            {
                get;
                set;
            }
            public string tpidUsed
            {
                get;
                set;
            }
            public string matchedCurrency
            {
                get;
                set;
            }
            public string matchedLocale
            {
                get;
                set;
            }
        }

        public class ChargeableNightlyRate
        {
            public string baseRate
            {
                get;
                set;
            }
            public string rate
            {
                get;
                set;
            }
            public string promo
            {
                get;
                set;
            }
        }

        public class Room
        {
            public int numberOfAdults
            {
                get;
                set;
            }
            public int numberOfChildren
            {
                get;
                set;
            }
            public string rateKey
            {
                get;
                set;
            }
            public List<ChargeableNightlyRate> ChargeableNightlyRates
            {
                get;
                set;
            }
        }

        public class RoomGroup
        {
            public Room Room
            {
                get;
                set;
            }
        }

        public class NightlyRate
        {
            public string baseRate
            {
                get;
                set;
            }
            public string rate
            {
                get;
                set;
            }
            public string promo
            {
                get;
                set;
            }
        }

        public class NightlyRatesPerRoom
        {
            public string size
            {
                get;
                set;
            }
            public List<NightlyRate> NightlyRate
            {
                get;
                set;
            }
        }

        public class Surcharge
        {
            public string type
            {
                get;
                set;
            }
            public string amount
            {
                get;
                set;
            }
        }

        public class Surcharges
        {
            public string size
            {
                get;
                set;
            }
            public Surcharge Surcharge
            {
                get;
                set;
            }
        }

        public class ChargeableRateInfo
        {
            public string averageBaseRate
            {
                get;
                set;
            }
            public string averageRate
            {
                get;
                set;
            }
            public string commissionableUsdTotal
            {
                get;
                set;
            }
            public string currencyCode
            {
                get;
                set;
            }
            public string maxNightlyRate
            {
                get;
                set;
            }
            public string nightlyRateTotal
            {
                get;
                set;
            }
            public string surchargeTotal
            {
                get;
                set;
            }
            public string total
            {
                get;
                set;
            }
            public NightlyRatesPerRoom NightlyRatesPerRoom
            {
                get;
                set;
            }
            public Surcharges Surcharges
            {
                get;
                set;
            }
        }

        public class RateInfo
        {
            public string priceBreakdown
            {
                get;
                set;
            }
            public string promo
            {
                get;
                set;
            }
            public string rateChange
            {
                get;
                set;
            }
            public RoomGroup RoomGroup
            {
                get;
                set;
            }
            public ChargeableRateInfo ChargeableRateInfo
            {
                get;
                set;
            }
            public bool nonRefundable
            {
                get;
                set;
            }
            public string rateType
            {
                get;
                set;
            }
            public int promoId
            {
                get;
                set;
            }
            public string promoDescription
            {
                get;
                set;
            }
            public string promoType
            {
                get;
                set;
            }
            public long currentAllotment
            {
                get;
                set;
            }
        }

        public class RateInfos
        {
            public string size
            {
                get;
                set;
            }
            public RateInfo RateInfo
            {
                get;
                set;
            }
        }

        public class ValueAdds
        {
            public string size
            {
                get;
                set;
            }
            public object ValueAdd
            {
                get;
                set;
            }
        }

        public class RoomRateDetails
        {
            public int roomTypeCode
            {
                get;
                set;
            }
            public int rateCode
            {
                get;
                set;
            }
            public int maxRoomOccupancy
            {
                get;
                set;
            }
            public int quotedRoomOccupancy
            {
                get;
                set;
            }
            public int minGuestAge
            {
                get;
                set;
            }
            public string roomDescription
            {
                get;
                set;
            }
            public bool propertyAvailable
            {
                get;
                set;
            }
            public bool propertyRestricted
            {
                get;
                set;
            }
            public int expediaPropertyId
            {
                get;
                set;
            }
            public RateInfos RateInfos
            {
                get;
                set;
            }
            public ValueAdds ValueAdds
            {
                get;
                set;
            }
        }

        public class RoomRateDetailsList
        {
            public RoomRateDetails RoomRateDetails
            {
                get;
                set;
            }
        }

        public class HotelSummary
        {
            public string order
            {
                get;
                set;
            }
            public string ubsScore
            {
                get;
                set;
            }
            public int hotelId
            {
                get;
                set;
            }
            public string name
            {
                get;
                set;
            }
            public string address1
            {
                get;
                set;
            }
            public string city
            {
                get;
                set;
            }
            public string postalCode
            {
                get;
                set;
            }
            public string countryCode
            {
                get;
                set;
            }
            public string airportCode
            {
                get;
                set;
            }
            public string supplierType
            {
                get;
                set;
            }
            public int propertyCategory
            {
                get;
                set;
            }
            public double hotelRating
            {
                get;
                set;
            }
            public string hotelRatingDisplay
            {
                get;
                set;
            }
            public int confidenceRating
            {
                get;
                set;
            }
            public int amenityMask
            {
                get;
                set;
            }
            public double tripAdvisorRating
            {
                get;
                set;
            }
            public int tripAdvisorReviewCount
            {
                get;
                set;
            }
            public string tripAdvisorRatingUrl
            {
                get;
                set;
            }
            public string locationDescription
            {
                get;
                set;
            }
            public string shortDescription
            {
                get;
                set;
            }
            public double highRate
            {
                get;
                set;
            }
            public double lowRate
            {
                get;
                set;
            }
            public string rateCurrencyCode
            {
                get;
                set;
            }
            public double latitude
            {
                get;
                set;
            }
            public double longitude
            {
                get;
                set;
            }
            public double proximityDistance
            {
                get;
                set;
            }
            public string proximityUnit
            {
                get;
                set;
            }
            public bool hotelInDestination
            {
                get;
                set;
            }
            public string thumbNailUrl
            {
                get;
                set;
            }
            public string deepLink
            {
                get;
                set;
            }
            public RoomRateDetailsList RoomRateDetailsList
            {
                get;
                set;
            }
            public string address2
            {
                get;
                set;
            }
            public string stateProvinceCode
            {
                get;
                set;
            }
        }

        public class HotelList
        {
            public string size
            {
                get;
                set;
            }
            public string activePropertyCount
            {
                get;
                set;
            }
            public List<HotelSummary> HotelSummary
            {
                get;
                set;
            }
        }

        public class HotelListResponse
        {
            public string customerSessionId
            {
                get;
                set;
            }
            public int numberOfRoomsRequested
            {
                get;
                set;
            }
            public bool moreResultsAvailable
            {
                get;
                set;
            }
            public string cacheKey
            {
                get;
                set;
            }
            public string cacheLocation
            {
                get;
                set;
            }
            public CachedSupplierResponse cachedSupplierResponse
            {
                get;
                set;
            }
            public HotelList HotelList
            {
                get;
                set;
            }
        }

        public class RootObject
        {
            public HotelListResponse HotelListResponse
            {
                get;
                set;
            }

            public HotelInformationResponse HotelInformationResponse
            {
                get;
                set;
            }
        }

        public class HotelDetails
        {
            public int numberOfRooms { get; set; }
            public int numberOfFloors { get; set; }
            public string checkInTime { get; set; }
            public string checkOutTime { get; set; }
            public string propertyInformation { get; set; }
            public string areaInformation { get; set; }
            public string propertyDescription { get; set; }
            public string hotelPolicy { get; set; }
            public string roomInformation { get; set; }
            public string drivingDirections { get; set; }
            public string checkInInstructions { get; set; }
            public string roomFeesDescription { get; set; }
            public string mandatoryFeesDescription { get; set; }
            public string locationDescription { get; set; }
            public string diningDescription { get; set; }
            public string amenitiesDescription { get; set; }
            public string businessAmenitiesDescription { get; set; }
            public string roomDetailDescription { get; set; }
            public string specialCheckInInstructions { get; set; }
        }

        public class Supplier
        {
            public string id { get; set; }
            public string chainCode { get; set; }
        }

        public class Suppliers
        {
            public string size { get; set; }
            public Supplier Supplier { get; set; }
        }

        public class RoomAmenity
        {
            public string amenityId { get; set; }
            public string amenity { get; set; }
        }

        public class RoomAmenities
        {
            public string size { get; set; }
            public List<RoomAmenity> RoomAmenity { get; set; }
        }

        public class RoomType
        {
            public string roomTypeId { get; set; }
            public string roomCode { get; set; }
            public string description { get; set; }
            public string descriptionLong { get; set; }
            public RoomAmenities roomAmenities { get; set; }
        }

        public class RoomTypes
        {
            public string size { get; set; }
            public List<RoomType> RoomType { get; set; }
        }

        public class PropertyAmenity
        {
            public int amenityId { get; set; }
            public string amenity { get; set; }
        }

        public class PropertyAmenities
        {
            public string size { get; set; }
            public List<PropertyAmenity> PropertyAmenity { get; set; }
        }

        public class HotelImage
        {
            public int hotelImageId { get; set; }
            public string name { get; set; }
            public int category { get; set; }
            public int type { get; set; }
            public string caption { get; set; }
            public string url { get; set; }
            public string thumbnailUrl { get; set; }
            public int supplierId { get; set; }
            public int width { get; set; }
            public int height { get; set; }
            public int byteSize { get; set; }
        }

        public class HotelImages
        {
            public string size { get; set; }
            public List<HotelImage> HotelImage { get; set; }
        }

        public class HotelInformationResponse
        {
            public string hotelId { get; set; }
            public string customerSessionId { get; set; }
            public HotelSummary HotelSummary { get; set; }
            public HotelDetails HotelDetails { get; set; }
            public Suppliers Suppliers { get; set; }
            public RoomTypes RoomTypes { get; set; }
            public PropertyAmenities PropertyAmenities { get; set; }
            public HotelImages HotelImages { get; set; }
        }

        private static string MD5GenerateHash(string strInput)
        {
            // Create a new instance of the MD5CryptoServiceProvider object.
            MD5 md5Hasher = MD5.Create();

            // Convert the input string to a byte array and compute the hash.
            byte[] data = md5Hasher.ComputeHash(Encoding.Default.GetBytes(strInput));

            // Create a new Stringbuilder to collect the bytes and create a string.
            StringBuilder sBuilder = new StringBuilder();

            // Loop through each byte of the hashed data and format each one as a hexadecimal string.
            for (int nIndex = 0; nIndex < data.Length; ++nIndex)
            {
                sBuilder.Append(data[nIndex].ToString("x2"));
            }

            // Return the hexadecimal string.
            return sBuilder.ToString();
        }

        public void ButtonSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string locale = DropDownListLocale.Text;
                string currency = DropDownListCurrency.Text;
                string country = DropDownListCountry.Text;
                string city = DropDownListCity.Text;
                string arrivalDate = CalendarCheckIn.SelectedDate.ToString("MM/dd/yyyy");
                string departureDate = CalendarCheckOut.SelectedDate.ToString("MM/dd/yyyy");
                string rooms = DropDownListRooms.Text;
                string adults = DropDownListAdults.Text;
                string numberOfResults = DropDownListNumberOfResults.Text;
                string minStarRating = DropDownListMinStar.Text;
                string maxStarRating = DropDownListMaxStar.Text;
                string cid = "488640";
                string minorRev = "99";
                string customerUserAgent = "Mozilla/5.0";
                string customerIpAddress = "84.246.168.11";
                //string customerSessionId = Session.SessionID.ToString();
                string apiKey = "5qjdrl3pjpj8f8gj6u7b40ofjk";
                string secret = "7elsc10rm4ejd";
                long timestamp = ((Int32)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds);
                string sig = MD5GenerateHash(apiKey + secret + timestamp);

                searchRequest.AddParameter("apikey", apiKey);
                searchRequest.AddParameter("sig", sig);
                searchRequest.AddParameter("cid", cid);
                searchRequest.AddParameter("minorRev", minorRev);
                searchRequest.AddParameter("customerUserAgent", customerUserAgent);
                searchRequest.AddParameter("customerIpAddress", customerIpAddress);
                //searchRequest.AddParameter("customerSessionId", customerSessionId);
                searchRequest.AddParameter("apikey", apiKey);
                searchRequest.AddParameter("locale", locale);
                searchRequest.AddParameter("currencyCode", currency);
                searchRequest.AddParameter("country", country);
                searchRequest.AddParameter("city", city);
                searchRequest.AddParameter("arrivalDate", arrivalDate);
                searchRequest.AddParameter("departureDate", departureDate);
                searchRequest.AddParameter("rooms", rooms);
                searchRequest.AddParameter("adults", adults);
                searchRequest.AddParameter("numberOfResults", numberOfResults);
                searchRequest.AddParameter("minStarRating", minStarRating);
                searchRequest.AddParameter("maxStarRating", maxStarRating);

                //Create and authenticate the web request
                searchRequest.UseDefaultCredentials = true;
                searchRequest.Credentials = CredentialCache.DefaultCredentials;

                //Get a response
                IRestResponse<RootObject> searchResponse = client.Execute<RootObject>(searchRequest);

                //Record the request
                TextBoxAPICall.Text = searchResponse.ResponseUri.OriginalString.ToString();

                var hotelList = searchResponse.Data.HotelListResponse.HotelList.HotelSummary.ToArray();

                foreach (var hotelSummary in hotelList.ToArray())
                {
                    GridViewResults.DataSource = hotelList;
                    GridViewResults.DataBind();
                }

            }

            catch (Exception exception)
            {
                //ClientScript.RegisterStartupScript(this.GetType(), "Error occured: ", "alert('" + exception.Message + "');", true);                
            }
        }

        protected void GridViewResults_SelectedIndexChanged(object sender, EventArgs e)
        {
            string _hotelId = GridViewResults.SelectedDataKey.Value.ToString();

            try
            {
                var searchListRequest = new RestRequest("/ean-services/rs/hotel/v3/info", Method.GET);

                string hotelId = _hotelId;
                string locale = DropDownListLocale.Text;
                string currency = DropDownListCurrency.Text;
                string country = DropDownListCountry.Text;
                string city = DropDownListCity.Text;
                string arrivalDate = CalendarCheckIn.SelectedDate.ToString("MM/dd/yyyy");
                string departureDate = CalendarCheckOut.SelectedDate.ToString("MM/dd/yyyy");
                string rooms = DropDownListRooms.Text;
                string adults = DropDownListAdults.Text;
                string numberOfResults = DropDownListNumberOfResults.Text;
                string minStarRating = DropDownListMinStar.Text;
                string maxStarRating = DropDownListMaxStar.Text;
                string cid = "488640";
                string minorRev = "99";
                string customerUserAgent = "Mozilla/5.0";
                string customerIpAddress = "84.246.168.11";
                //string customerSessionId = Session.SessionID.ToString();
                string apiKey = "5qjdrl3pjpj8f8gj6u7b40ofjk";
                string secret = "7elsc10rm4ejd";
                long timestamp = ((Int32)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds);
                string sig = MD5GenerateHash(apiKey + secret + timestamp);

                searchListRequest.AddParameter("apikey", apiKey);
                searchListRequest.AddParameter("sig", sig);
                searchListRequest.AddParameter("cid", cid);
                searchListRequest.AddParameter("minorRev", minorRev);
                searchListRequest.AddParameter("customerUserAgent", customerUserAgent);
                searchListRequest.AddParameter("customerIpAddress", customerIpAddress);
                //searchListRequest.AddParameter("customerSessionId", customerSessionId);
                searchListRequest.AddParameter("locale", locale);
                searchListRequest.AddParameter("currencyCode", currency);
                searchListRequest.AddParameter("hotelId", hotelId);

                //Create and authenticate the web request
                searchListRequest.UseDefaultCredentials = true;
                searchListRequest.Credentials = CredentialCache.DefaultCredentials;

                //Get a response
                IRestResponse<RootObject> hotelInformationResponse = client.Execute<RootObject>(searchListRequest);

                //Record the request
                TextBoxAPICall.Text = hotelInformationResponse.ResponseUri.OriginalString.ToString();

                var hotelInformationList = hotelInformationResponse.Data.HotelInformationResponse.RoomTypes.RoomType;

                foreach (var hotelSummary in hotelInformationList.ToArray())
                {
                    GridViewHotel.DataSource = hotelInformationList;
                    GridViewHotel.DataBind();
                }
            }

            catch (Exception exception)
            {
                //ClientScript.RegisterStartupScript(this.GetType(), "Error occured: ", "alert('" + exception.Message + "');", true);                
            }
        }

        protected void ButtonClear_Click(object sender, EventArgs e)
        {
            TextBoxAPICall.Text = String.Empty;
            GridViewResults.DataSourceID = null;
            GridViewResults.DataBind();
            GridViewHotel.DataSourceID = null;
            GridViewHotel.DataBind();
            //TextBoxResults.Text = String.Empty;
        }

        //protected void GridViewResults_RowCommand(object sender, GridViewCommandEventArgs e)
        //{
        //    foreach (GridViewRow row in GridViewResults.Rows)
        //    {
        //        string _hotelId = GridViewResults.DataKeys[row.RowIndex].Value.ToString();

        //        try
        //        {
        //            var searchListRequest = new RestRequest("/ean-services/rs/hotel/v3/info", Method.GET);

        //            string hotelId = _hotelId;
        //            string locale = DropDownListLocale.Text;
        //            string currency = DropDownListCurrency.Text;
        //            string country = DropDownListCountry.Text;
        //            string city = DropDownListCity.Text;
        //            string arrivalDate = CalendarCheckIn.SelectedDate.ToString("MM/dd/yyyy");
        //            string departureDate = CalendarCheckOut.SelectedDate.ToString("MM/dd/yyyy");
        //            string rooms = DropDownListRooms.Text;
        //            string adults = DropDownListAdults.Text;
        //            string numberOfResults = DropDownListNumberOfResults.Text;
        //            string minStarRating = DropDownListMinStar.Text;
        //            string maxStarRating = DropDownListMaxStar.Text;
        //            string cid = "488640";
        //            string minorRev = "99";
        //            string customerUserAgent = "Mozilla/5.0";
        //            string customerIpAddress = "84.246.168.11";
        //            //string customerSessionId = Session.SessionID.ToString();
        //            string apiKey = "5qjdrl3pjpj8f8gj6u7b40ofjk";
        //            string secret = "7elsc10rm4ejd";
        //            long timestamp = ((Int32)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds);
        //            string sig = MD5GenerateHash(apiKey + secret + timestamp);

        //            searchListRequest.AddParameter("apikey", apiKey);
        //            searchListRequest.AddParameter("sig", sig);
        //            searchListRequest.AddParameter("cid", cid);
        //            searchListRequest.AddParameter("minorRev", minorRev);
        //            searchListRequest.AddParameter("customerUserAgent", customerUserAgent);
        //            searchListRequest.AddParameter("customerIpAddress", customerIpAddress);
        //            //searchListRequest.AddParameter("customerSessionId", customerSessionId);
        //            searchListRequest.AddParameter("locale", locale);
        //            searchListRequest.AddParameter("currencyCode", currency);
        //            searchListRequest.AddParameter("hotelId", hotelId);

        //            //Create and authenticate the web request
        //            searchListRequest.UseDefaultCredentials = true;
        //            searchListRequest.Credentials = CredentialCache.DefaultCredentials;

        //            //Get a response
        //            IRestResponse<RootObject> hotelInformationResponse = client.Execute<RootObject>(searchListRequest);

        //            //Record the request
        //            TextBoxAPICall.Text = hotelInformationResponse.ResponseUri.OriginalString.ToString();

        //            var hotelInformationList = hotelInformationResponse.Data.HotelInformationResponse.hotelId.ToString();

        //            //foreach (var hotelSummary in hotelList.ToArray())
        //            //{
        //            //    GridViewResults.DataSource = hotelList;
        //            //    GridViewResults.DataBind();
        //            //}
        //        }

        //        catch (Exception exception)
        //        {
        //            //ClientScript.RegisterStartupScript(this.GetType(), "Error occured: ", "alert('" + exception.Message + "');", true);                
        //        }
        //    }
        //}
    }
}